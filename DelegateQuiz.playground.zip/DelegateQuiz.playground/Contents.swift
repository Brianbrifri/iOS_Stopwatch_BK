/// Delegation Quiz

import UIKit
protocol myProtocol {
    func stringWasAdded(with text: String)
    func multipleStringsWereAdded(with array: [String])
}

class MyModel {

    var delegate: myProtocol?
	private(set) var dataSet: [String]
	
    init() {
		dataSet = []
	}
	
	func add(new stringValue: String) {
		dataSet.append(stringValue)
        delegate?.stringWasAdded(with: stringValue)
        
	}
	
	func add(arrayOf stringValues: [String]) {
		dataSet.appendContentsOf(stringValues)
        delegate?.multipleStringsWereAdded(with: stringValues)
	}
}


class Controller: myProtocol {


	var model: MyModel!
	var delegateCallCount = 0
	var stringAddedCount = 0
	var arrayAddedCount = 0

	init(model: MyModel) {
        self.model = MyModel()
        model.delegate = self
	}
	
	func whatIsInTheArray() -> String {
		return model.dataSet.reduce("", combine: {$0 + " " + $1})
	}
	
	// MARK - MyModel Delegate methods
	func stringWasAdded(with text: String) {
		delegateCallCount += 1
		stringAddedCount += 1
		print(stringAddedCount == 1) /// Should print True
	}
	
	func multipleStringsWereAdded(with array: [String]) {
		array.reduce("") { (startingString, value) -> String in
			return startingString + " : " + value
		}
		delegateCallCount += 1
		arrayAddedCount += 1
		print(arrayAddedCount == 1) /// Should print True
	}
}


/// The code exists to increment `delegateCallCount` already. Your task is to establish
/// delegation communication between MyModel and Controller classes.
///
/// Read the above code completely as well as the function calls listed in #1.

/// 1. Add a delegate on MyModel so that when you add a single string AND add an array of string
/// the controller is notified using delegation.
let testModel = MyModel()
let myController = Controller(model: testModel)
testModel.add(new: "My First string") /// delegateCallCount should increase by 1 after calling this function
testModel.add(arrayOf: ["second string", "third string"]) /// delegateCallCount should increase by 1
myController.whatIsInTheArray()


/// 2. Implement the delegate so that delegateCallCount == 2
myController.delegateCallCount == 2








